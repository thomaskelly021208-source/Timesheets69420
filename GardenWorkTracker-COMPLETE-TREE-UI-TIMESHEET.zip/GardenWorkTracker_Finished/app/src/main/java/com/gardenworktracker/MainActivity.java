package com.gardenworktracker;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.location.*;
import android.net.Uri;
import android.os.*;
import android.provider.DocumentsContract;
import android.view.*;
import android.widget.*;
import java.io.File;
import java.util.*;

public class MainActivity extends Activity {
    Database db;
    LinearLayout root, body;
    TextView title;
    Handler clock = new Handler(Looper.getMainLooper());
    BroadcastReceiver receiver;
    Button navWork, navTimes, navEdging, navCustomers;
    String pendingExportKind;
    final int EXPORT_WEEK = 400, EXPORT_EDGING = 401, EXPORT_MONTH = 402, EXPORT_YEAR = 403, EXPORT_ALL = 404, PICK_EXPORT_FOLDER = 500;

    final int green = Color.rgb(47,91,56), green2 = Color.rgb(232,241,233), ink = Color.rgb(31,36,32), muted = Color.rgb(105,112,106), bg = Color.rgb(247,248,246), white = Color.WHITE, danger = Color.rgb(150,48,48), amber = Color.rgb(160,103,0);
    int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        db = new Database(this);
        requestPermissions();
        build();
        recover();
        receiver = new BroadcastReceiver() {
            public void onReceive(Context c, Intent i) {
                if (LocationService.ACTION_CANDIDATE.equals(i.getAction())) candidate(i.getStringExtra("customerId"), i.getIntExtra("distance",0));
                else if (LocationService.ACTION_DEPART.equals(i.getAction())) departure();
            }
        };
        IntentFilter f = new IntentFilter();
        f.addAction(LocationService.ACTION_CANDIDATE);
        f.addAction(LocationService.ACTION_DEPART);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver,f,Context.RECEIVER_NOT_EXPORTED); else registerReceiver(receiver,f);
        startTracking();
    }

    void requestPermissions() {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},20);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},21);
    }
    void startTracking(){try{startForegroundService(new Intent(this,LocationService.class));}catch(Exception ignored){}}
    void configureWindow(){
        if(Build.VERSION.SDK_INT>=30)getWindow().setDecorFitsSystemWindows(true);
        getWindow().setStatusBarColor(bg); getWindow().setNavigationBarColor(bg);
        if(Build.VERSION.SDK_INT>=23)getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
    }

    TextView tv(String s,float sp){TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setTextColor(ink);t.setGravity(Gravity.CENTER_VERTICAL);t.setPadding(dp(4),dp(4),dp(4),dp(4));return t;}
    TextView centered(String s,float sp){TextView t=tv(s,sp);t.setGravity(Gravity.CENTER);return t;}
    GradientDrawable shape(int color,float radius){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(radius));return g;}
    Button btn(String s){Button b=new Button(this);b.setText(s);b.setTextSize(15);b.setTextColor(ink);b.setAllCaps(false);b.setSingleLine(true);b.setEllipsize(null);b.setMinHeight(dp(52));b.setPadding(dp(12),0,dp(12),0);b.setBackground(shape(white,14));return b;}
    Button primary(String s){Button b=btn(s);b.setTextColor(white);b.setBackground(shape(green,14));return b;}
    TextView section(String s){TextView t=tv(s.toUpperCase(Locale.UK),13);t.setTextColor(green);t.setTypeface(null,1);t.setPadding(dp(4),dp(14),dp(4),dp(7));return t;}
    void card(View v){v.setBackground(shape(white,18));v.setPadding(dp(16),dp(14),dp(16),dp(14));}
    void margin(View v,int bottom){v.setLayoutParams(new LinearLayout.LayoutParams(-1,LinearLayout.LayoutParams.WRAP_CONTENT));v.setPadding(v.getPaddingLeft(),v.getPaddingTop(),v.getPaddingRight(),v.getPaddingBottom());}

    void build(){
        configureWindow();
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(bg);
        root.setPadding(dp(16),dp(12),dp(16),dp(10));

        LinearLayout header=new LinearLayout(this); header.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout brand=new LinearLayout(this); brand.setOrientation(LinearLayout.VERTICAL); brand.setGravity(Gravity.CENTER_VERTICAL);
        title=tv("GARDEN WORK TRACKER",18); title.setTypeface(null,1); title.setTextColor(ink);
        brand.addView(title,new LinearLayout.LayoutParams(-1,dp(28)));
        TextView sub=tv("OFFLINE • GPS READY",11); sub.setTextColor(muted); brand.addView(sub,new LinearLayout.LayoutParams(-1,dp(20)));
        header.addView(brand,new LinearLayout.LayoutParams(0,dp(52),1));
        Button settings=navButton("⚙"); settings.setTextSize(18); settings.setContentDescription("Settings");
        header.addView(settings,new LinearLayout.LayoutParams(dp(48),dp(48)));
        settings.setOnClickListener(v->settingsDialog());
        root.addView(header,new LinearLayout.LayoutParams(-1,dp(54)));

        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true); scroll.setClipToPadding(false);
        body=new LinearLayout(this); body.setOrientation(LinearLayout.VERTICAL); body.setPadding(0,dp(4),0,dp(16));
        scroll.addView(body,new ScrollView.LayoutParams(-1,-2));
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));

        LinearLayout nav=new LinearLayout(this); nav.setGravity(Gravity.CENTER_VERTICAL); nav.setPadding(0,dp(6),0,0);
        navWork=navButton("WORK"); navTimes=navButton("TIMES"); navEdging=navButton("EDGING"); navCustomers=navButton("CUSTOMERS");
        nav.addView(navWork,new LinearLayout.LayoutParams(0,dp(50),1)); nav.addView(navTimes,new LinearLayout.LayoutParams(0,dp(50),1)); nav.addView(navEdging,new LinearLayout.LayoutParams(0,dp(50),1)); nav.addView(navCustomers,new LinearLayout.LayoutParams(0,dp(50),1));
        navWork.setOnClickListener(v->work()); navTimes.setOnClickListener(v->timesheet()); navEdging.setOnClickListener(v->edging()); navCustomers.setOnClickListener(v->customers());
        root.addView(nav,new LinearLayout.LayoutParams(-1,dp(56)));
        setContentView(root); work();
    }
    Button navButton(String s){Button b=btn(s);b.setTextSize(11.5f);b.setTypeface(null,1);b.setPadding(dp(1),0,dp(1),0);b.setMinHeight(0);b.setSingleLine(true);return b;}
    void settingsDialog(){
        String current=exportFolder()==null?"Not selected":"A folder is selected";
        new AlertDialog.Builder(this).setTitle("SETTINGS")
            .setItems(new String[]{"EXPORT FOLDER  •  "+current,"CANCEL"},(d,w)->{if(w==0)chooseExportFolder();})
            .show();
    }
    void setSelected(Button selected){for(Button b:new Button[]{navWork,navTimes,navEdging,navCustomers}){b.setTextColor(ink);b.setBackground(shape(white,14));}selected.setTextColor(green);selected.setBackground(shape(green2,14));}
    void clear(){body.removeAllViews();}
    void add(View v,int h){body.addView(v,new LinearLayout.LayoutParams(-1,dp(h)));}
    void addWrap(View v,int bottom){LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,LinearLayout.LayoutParams.WRAP_CONTENT);lp.setMargins(0,0,0,dp(bottom));body.addView(v,lp);}

    void work(){
        clear(); setSelected(navWork);
        long now=System.currentTimeMillis();
        LinearLayout dateRow=new LinearLayout(this); dateRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView date=tv("TODAY  •  "+TimeUtil.date(now),12); date.setTextColor(muted); date.setTypeface(null,1);
        dateRow.addView(date,new LinearLayout.LayoutParams(0,dp(30),1));
        add(dateRow,32);
        TextView clockTv=centered("",38); clockTv.setTypeface(null,1); clockTv.setTextColor(ink); add(clockTv,56);
        Runnable r=new Runnable(){public void run(){if(!clockTv.isAttachedToWindow())return;clockTv.setText(TimeUtil.time(System.currentTimeMillis()));clock.postDelayed(this,1000);}}; r.run();
        HashMap<String,Object> v=db.activeVisit();
        if(v==null){
            LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setGravity(Gravity.CENTER);card(c);
            TextView s=centered("READY FOR WORK",18);s.setTypeface(null,1);c.addView(s,new LinearLayout.LayoutParams(-1,dp(40)));
            TextView m=centered("GPS is watching for your next customer",13);m.setTextColor(muted);c.addView(m,new LinearLayout.LayoutParams(-1,dp(36)));
            addWrap(c,10);Button start=primary("START JOB");add(start,54);start.setOnClickListener(x->chooseCustomer());
        } else showActive(v);
    }

    void showActive(HashMap<String,Object> v){
        String cid=(String)v.get("customer_id"); HashMap<String,Object> customer=db.customer(cid); String name=customer==null?"Unknown customer":String.valueOf(customer.get("name")); String st=String.valueOf(v.get("status"));
        LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);card(c);
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);
        TextView n=tv(name,22);n.setTypeface(null,1);top.addView(n,new LinearLayout.LayoutParams(0,dp(42),1));
        TextView state=tv(st.equals("ON_BREAK")?"ON BREAK":st.equals("POSSIBLE_DEPARTURE")?"LEFT?":"WORKING",12);state.setGravity(Gravity.CENTER);state.setTypeface(null,1);state.setTextColor(st.equals("ON_BREAK")?amber:green);state.setBackground(shape(green2,12));top.addView(state,new LinearLayout.LayoutParams(dp(88),dp(34)));
        c.addView(top);
        long start=Long.parseLong(String.valueOf(v.get("start_ts")));
        TextView times=tv("Started "+TimeUtil.time(start)+"    •    "+v.get("workers")+" workers",14);times.setTextColor(muted);c.addView(times,new LinearLayout.LayoutParams(-1,dp(38)));
        addWrap(c,10);
        if(st.equals("ON_BREAK")){
            Button b=primary("RESUME WORK");add(b,54);b.setOnClickListener(x->{HashMap<String,Object>ob=db.openBreak((String)v.get("id"));if(ob!=null)db.closeBreak((String)ob.get("id"),System.currentTimeMillis());db.updateVisit((String)v.get("id"),cid,start,null,Integer.parseInt(String.valueOf(v.get("workers"))),"WORKING","MANUAL");work();});
        } else if(st.equals("POSSIBLE_DEPARTURE")){
            Button b=primary("FINISH JOB");add(b,54);b.setOnClickListener(x->finish(v));Button k=btn("KEEP WORKING");add(k,50);k.setOnClickListener(x->{db.updateVisit((String)v.get("id"),cid,start,null,Integer.parseInt(String.valueOf(v.get("workers"))),"WORKING","MANUAL");work();});
        } else {
            Button f=primary("FINISH JOB");add(f,54);f.setOnClickListener(x->finish(v));
            Button br=btn("START BREAK");add(br,50);br.setOnClickListener(x->{db.addBreak((String)v.get("id"),System.currentTimeMillis());db.updateVisit((String)v.get("id"),cid,start,null,Integer.parseInt(String.valueOf(v.get("workers"))),"ON_BREAK","MANUAL");work();});
            LinearLayout w=new LinearLayout(this);w.setGravity(Gravity.CENTER_VERTICAL);w.setPadding(0,dp(3),0,0);
            TextView wt=tv("WORKERS",13);wt.setTextColor(muted);w.addView(wt,new LinearLayout.LayoutParams(0,dp(46),1));
            Button minus=btn("−"),plus=btn("+"); TextView count=centered(String.valueOf(v.get("workers")),17);count.setTypeface(null,1);
            w.addView(minus,new LinearLayout.LayoutParams(dp(52),dp(46)));w.addView(count,new LinearLayout.LayoutParams(dp(44),dp(46)));w.addView(plus,new LinearLayout.LayoutParams(dp(52),dp(46)));body.addView(w,new LinearLayout.LayoutParams(-1,dp(52)));
            minus.setOnClickListener(x->{int z=Math.max(1,Integer.parseInt(String.valueOf(v.get("workers")))-1);db.updateVisit((String)v.get("id"),cid,start,null,z,"WORKING","MANUAL");work();});
            plus.setOnClickListener(x->{int z=Integer.parseInt(String.valueOf(v.get("workers")))+1;db.updateVisit((String)v.get("id"),cid,start,null,z,"WORKING","MANUAL");work();});
        }
    }

    void chooseCustomer(){ArrayList<HashMap<String,Object>>cs=db.customers();ArrayList<HashMap<String,Object>>active=new ArrayList<>();for(HashMap<String,Object>x:cs)if(Boolean.TRUE.equals(x.get("active")))active.add(x);ArrayList<String>names=new ArrayList<>();for(HashMap<String,Object>x:active)names.add(String.valueOf(x.get("name")));names.add("NONE / SEARCH");new AlertDialog.Builder(this).setTitle("START JOB").setItems(names.toArray(new String[0]),(d,w)->{if(w==active.size())searchCustomer();else{db.insertVisit(String.valueOf(active.get(w).get("id")),System.currentTimeMillis(),2,"MANUAL");work();}}).show();}
    void searchCustomer(){final EditText e=new EditText(this);e.setHint("Customer name");new AlertDialog.Builder(this).setTitle("CUSTOMER SEARCH").setView(e).setPositiveButton("SEARCH",(d,w)->{String q=e.getText().toString();ArrayList<HashMap<String,Object>>cs=db.customers();cs.sort((a,b)->Integer.compare(Match.score(q,String.valueOf(a.get("name")),String.valueOf(a.get("aliases"))),Match.score(q,String.valueOf(b.get("name")),String.valueOf(b.get("aliases")))));if(!cs.isEmpty())candidate(String.valueOf(cs.get(0).get("id")),0);}).setNegativeButton("CANCEL",null).show();}
    void candidate(String cid,int distance){HashMap<String,Object>c=db.customer(cid);if(c==null)return;new AlertDialog.Builder(this).setTitle("POSSIBLE ARRIVAL").setMessage(c.get("name")+"\nAbout "+distance+" m away").setPositiveButton("YES",(d,w)->{db.insertVisit(cid,System.currentTimeMillis(),2,"GPS");work();}).setNegativeButton("NO",(d,w)->nearby()).show();}
    void nearby(){ArrayList<HashMap<String,Object>>cs=db.customers();ArrayList<String>names=new ArrayList<>();for(int i=0;i<Math.min(5,cs.size());i++)names.add(String.valueOf(cs.get(i).get("name")));new AlertDialog.Builder(this).setTitle("CUSTOMERS NEARBY").setItems(names.toArray(new String[0]),(d,w)->{db.insertVisit(String.valueOf(cs.get(w).get("id")),System.currentTimeMillis(),2,"MANUAL");work();}).setNegativeButton("NONE",null).show();}
    void departure(){HashMap<String,Object>v=db.activeVisit();if(v==null)return;HashMap<String,Object>c=db.customer(String.valueOf(v.get("customer_id")));new AlertDialog.Builder(this).setTitle("LOOKS LIKE YOU'VE LEFT").setMessage("Finish "+(c==null?"this job":c.get("name"))+"?").setPositiveButton("FINISH JOB",(d,w)->finish(v)).setNegativeButton("KEEP WORKING",null).show();}
    void finish(HashMap<String,Object>v){long end=System.currentTimeMillis(),st=Long.parseLong(String.valueOf(v.get("start_ts")));long mins=Math.max(0,(end-st)/60000-db.breakMinutes(String.valueOf(v.get("id"))));new AlertDialog.Builder(this).setTitle("FINISH JOB").setMessage(TimeUtil.time(st)+" → "+TimeUtil.time(end)+"\n"+mins+" minutes worked").setPositiveButton("FINISH JOB",(d,w)->{db.updateVisit(String.valueOf(v.get("id")),String.valueOf(v.get("customer_id")),st,end,Integer.parseInt(String.valueOf(v.get("workers"))),"COMPLETED",String.valueOf(v.get("creation_method")));backup();work();}).setNegativeButton("KEEP WORKING",null).show();}
    void recover(){HashMap<String,Object>v=db.activeVisit();if(v!=null){HashMap<String,Object>c=db.customer(String.valueOf(v.get("customer_id")));new AlertDialog.Builder(this).setTitle("ACTIVE JOB FOUND").setMessage((c==null?"Unknown customer":c.get("name"))+"\nStarted "+TimeUtil.time(Long.parseLong(String.valueOf(v.get("start_ts"))))).setPositiveButton("CONTINUE",(d,w)->work()).setNeutralButton("EDIT",null).setNegativeButton("FINISH JOB",(d,w)->finish(v)).show();}}

    void timesheet(){
        clear();setSelected(navTimes);
        addWrap(section("Timesheet"),2);
        long now=System.currentTimeMillis(),ws=TimeUtil.weekStart(now),we=TimeUtil.addDays(ws,7);
        LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.VERTICAL);card(info);
        TextView a=tv("CURRENT WEEK",11);a.setTextColor(green);a.setTypeface(null,1);info.addView(a,new LinearLayout.LayoutParams(-1,dp(24)));
        TextView range=tv(TimeUtil.shortDate(ws)+" – "+TimeUtil.shortDate(TimeUtil.addDays(we,-1)),20);range.setTypeface(null,1);info.addView(range,new LinearLayout.LayoutParams(-1,dp(36)));
        TextView note=tv("Rolls forward every Monday. Older jobs stay permanently in history.",13);note.setTextColor(muted);note.setLineSpacing(0,1.05f);info.addView(note,new LinearLayout.LayoutParams(-1,LinearLayout.LayoutParams.WRAP_CONTENT));
        addWrap(info,10);

        TextView exportTitle=section("Exports");addWrap(exportTitle,1);
        Button folder=btn(exportFolderLabel());add(folder,46);folder.setOnClickListener(v->chooseExportFolder());
        Button ex=primary("EXPORT THIS WEEK");add(ex,52);ex.setOnClickListener(v->startExport("xlsx"));
        LinearLayout exportRow=new LinearLayout(this);exportRow.setGravity(Gravity.CENTER_VERTICAL);
        Button month=btn("MONTH");Button year=btn("YEAR");Button all=btn("ALL HISTORY");
        exportRow.addView(month,new LinearLayout.LayoutParams(0,dp(48),1));exportRow.addView(year,new LinearLayout.LayoutParams(0,dp(48),1));exportRow.addView(all,new LinearLayout.LayoutParams(0,dp(48),1));
        body.addView(exportRow,new LinearLayout.LayoutParams(-1,dp(52)));month.setOnClickListener(v->startExport("xlsxMonth"));year.setOnClickListener(v->startExport("xlsxYear"));all.setOnClickListener(v->startExport("xlsxAll"));

        addWrap(section("Recent jobs"),2);
        ArrayList<HashMap<String,Object>> visits=db.allVisits();
        if(visits.isEmpty()){
            LinearLayout empty=new LinearLayout(this);empty.setOrientation(LinearLayout.VERTICAL);card(empty);TextView e=centered("NO JOBS YET",16);e.setTypeface(null,1);empty.addView(e,new LinearLayout.LayoutParams(-1,dp(42)));TextView m=centered("Completed visits will appear here.",13);m.setTextColor(muted);empty.addView(m,new LinearLayout.LayoutParams(-1,dp(34)));addWrap(empty,8);
        } else for(HashMap<String,Object>x:visits){
            long st=Long.parseLong(String.valueOf(x.get("start_ts")));Object e=x.get("end_ts");long mins=e==null?0:Math.max(0,(Long.parseLong(String.valueOf(e))-st)/60000-db.breakMinutes(String.valueOf(x.get("id"))));
            LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.VERTICAL);card(row);
            TextView rn=tv(String.valueOf(x.get("name")),17);rn.setTypeface(null,1);row.addView(rn,new LinearLayout.LayoutParams(-1,dp(28)));
            String details=TimeUtil.date(st)+"  •  "+TimeUtil.time(st)+" – "+(e==null?"NOW":TimeUtil.time(Long.parseLong(String.valueOf(e))))+"\n"+mins+" min  •  "+x.get("workers")+" workers";
            TextView rd=tv(details,13);rd.setTextColor(muted);rd.setLineSpacing(0,1.05f);row.addView(rd,new LinearLayout.LayoutParams(-1,dp(44)));
            TextView hint=tv("Tap to edit or delete",11);hint.setTextColor(green);row.addView(hint,new LinearLayout.LayoutParams(-1,dp(24)));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,LinearLayout.LayoutParams.WRAP_CONTENT);lp.setMargins(0,0,0,dp(8));body.addView(row,lp);row.setOnClickListener(v->editVisit(x));
        }
    }

    void editVisit(HashMap<String,Object>x){
        final EditText s=new EditText(this);s.setSingleLine(true);s.setText(TimeUtil.time(Long.parseLong(String.valueOf(x.get("start_ts")))));
        final EditText e=new EditText(this);e.setSingleLine(true);e.setText(x.get("end_ts")==null?"":TimeUtil.time(Long.parseLong(String.valueOf(x.get("end_ts")))));
        final EditText w=new EditText(this);w.setInputType(2);w.setSingleLine(true);w.setText(String.valueOf(x.get("workers")));
        LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(8),dp(4),dp(8),0);
        l.addView(tv("START HH:mm",14));l.addView(s,new LinearLayout.LayoutParams(-1,dp(52)));l.addView(tv("FINISH HH:mm",14));l.addView(e,new LinearLayout.LayoutParams(-1,dp(52)));l.addView(tv("WORKERS",14));l.addView(w,new LinearLayout.LayoutParams(-1,dp(52)));
        new AlertDialog.Builder(this).setTitle(String.valueOf(x.get("name"))).setView(l)
            .setPositiveButton("SAVE",(d,z)->{try{Calendar c=TimeUtil.cal(Long.parseLong(String.valueOf(x.get("start_ts"))));long ns=parseClock(s.getText().toString(),c);Long ne=e.getText().toString().trim().isEmpty()?null:parseClock(e.getText().toString(),c);int workers=Math.max(1,Integer.parseInt(w.getText().toString().trim()));String before=x.toString();db.updateVisit(String.valueOf(x.get("id")),String.valueOf(x.get("customer_id")),ns,ne,workers,"COMPLETED",String.valueOf(x.get("creation_method")));db.version(String.valueOf(x.get("id")),db.versionCount(String.valueOf(x.get("id")))+1,before,"edited","MANUAL");backup();timesheet();}catch(Exception ex){new AlertDialog.Builder(this).setTitle("Could not save").setMessage("Use times such as 08:30 and 16:45.").setPositiveButton("OK",null).show();}})
            .setNeutralButton("DELETE JOB",(d,z)->confirmDeleteVisit(x)).setNegativeButton("CANCEL",null).show();
    }
    void confirmDeleteVisit(HashMap<String,Object>x){new AlertDialog.Builder(this).setTitle("DELETE JOB?").setMessage("Delete this visit for "+x.get("name")+"?\n\nThis removes this job from the timesheet and edging records. The customer will NOT be deleted.").setPositiveButton("DELETE",(d,w)->{db.deleteVisit(String.valueOf(x.get("id")),x.toString());backup();timesheet();}).setNegativeButton("CANCEL",null).show();}
    long parseClock(String s,Calendar base){String[]q=s.trim().split(":");if(q.length!=2)throw new IllegalArgumentException();Calendar c=(Calendar)base.clone();int hh=Integer.parseInt(q[0]),mm=Integer.parseInt(q[1]);if(hh<0||hh>23||mm<0||mm>59)throw new IllegalArgumentException();c.set(Calendar.HOUR_OF_DAY,hh);c.set(Calendar.MINUTE,mm);c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);return c.getTimeInMillis();}

    void customers(){clear();setSelected(navCustomers);addWrap(section("Customers"),4);Button add=primary("NEW CUSTOMER");add(add,56);add.setOnClickListener(v->newCustomer());for(HashMap<String,Object>x:db.customers()){if(!Boolean.TRUE.equals(x.get("active")))continue;TextView t=tv(String.valueOf(x.get("name")),18);card(t);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(58));lp.setMargins(0,0,0,dp(7));body.addView(t,lp);t.setOnClickListener(v->customerMenu(x));}}
    void newCustomer(){final EditText e=new EditText(this);e.setHint("Customer name");new AlertDialog.Builder(this).setTitle("NEW CUSTOMER").setView(e).setPositiveButton("SAVE",(d,w)->{if(e.getText().toString().trim().isEmpty())return;db.addCustomer(e.getText().toString().trim(),"");customers();}).setNegativeButton("CANCEL",null).show();}
    void customerMenu(HashMap<String,Object>x){new AlertDialog.Builder(this).setTitle(String.valueOf(x.get("name"))).setItems(new String[]{"UPDATE LOCATION","EDIT CUSTOMER","DEACTIVATE"},(d,i)->{if(i==0)saveLocation(String.valueOf(x.get("id")));else if(i==1)editCustomer(x);else{db.updateCustomer(String.valueOf(x.get("id")),String.valueOf(x.get("name")),String.valueOf(x.get("aliases")),false);customers();}}).show();}
    void editCustomer(HashMap<String,Object>x){EditText e=new EditText(this);e.setSingleLine(true);e.setText(String.valueOf(x.get("name")));new AlertDialog.Builder(this).setTitle("EDIT CUSTOMER").setView(e).setPositiveButton("SAVE",(d,w)->{db.updateCustomer(String.valueOf(x.get("id")),e.getText().toString().trim(),String.valueOf(x.get("aliases")),true);customers();}).setNegativeButton("CANCEL",null).show();}
    void saveLocation(String cid){LocationManager lm=(LocationManager)getSystemService(LOCATION_SERVICE);if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED)return;try{Location l=lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);if(l==null){new AlertDialog.Builder(this).setMessage("GPS position unavailable. Try again outside.").setPositiveButton("OK",null).show();return;}db.addLocation(cid,l.getLatitude(),l.getLongitude(),l.getAccuracy());new AlertDialog.Builder(this).setMessage("Location saved.").setPositiveButton("OK",null).show();}catch(Exception ignored){}}

    void edging(){
        clear();setSelected(navEdging);addWrap(section("Edging sheet"),4);long now=System.currentTimeMillis(),start=TimeUtil.edgingSheetStart(now),end=TimeUtil.addDays(start,56);
        LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.VERTICAL);card(info);TextView a=tv("CURRENT 8-WEEK SHEET",13);a.setTextColor(green);a.setTypeface(null,1);info.addView(a,new LinearLayout.LayoutParams(-1,dp(28)));TextView r=tv(TimeUtil.shortDate(start)+" – "+TimeUtil.shortDate(TimeUtil.addDays(end,-1)),20);r.setTypeface(null,1);info.addView(r,new LinearLayout.LayoutParams(-1,dp(40)));TextView n=tv("The sheet rolls forward automatically after week 8. Previous weeks stay in your visit history.",14);n.setTextColor(muted);n.setLineSpacing(0,1.05f);info.addView(n,new LinearLayout.LayoutParams(-1,LinearLayout.LayoutParams.WRAP_CONTENT));addWrap(info,10);
        Button folder=btn(exportFolderLabel());add(folder,46);folder.setOnClickListener(v->chooseExportFolder());Button b=primary("EXPORT CURRENT A4 SHEET");add(b,56);b.setOnClickListener(v->startExport("edging"));
    }

    String exportFolder(){return getSharedPreferences("settings",MODE_PRIVATE).getString("export_tree_uri",null);}
    String exportFolderLabel(){return exportFolder()==null?"CHOOSE EXPORT FOLDER":"EXPORT FOLDER  •  SAVED";}
    void chooseExportFolder(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION|Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);startActivityForResult(i,PICK_EXPORT_FOLDER);}
    void startExport(String kind){pendingExportKind=kind;if(exportFolder()==null){new AlertDialog.Builder(this).setTitle("CHOOSE EXPORT FOLDER").setMessage("Choose or create a Garden Work Tracker folder. All future timesheets and edging sheets will be saved there automatically.").setPositiveButton("CHOOSE FOLDER",(d,w)->chooseExportFolder()).setNegativeButton("CANCEL",null).show();return;}performExport(kind);}
    Uri createExportUri(String filename,String mime)throws Exception{
        String s=exportFolder();if(s==null)return null;Uri tree=Uri.parse(s); Uri parent=DocumentsContract.buildDocumentUriUsingTree(tree,DocumentsContract.getTreeDocumentId(tree)); try{return DocumentsContract.createDocument(getContentResolver(),parent,mime,filename);}catch(SecurityException ex){getSharedPreferences("settings",MODE_PRIVATE).edit().remove("export_tree_uri").apply();throw ex;}
    }
    void performExport(String kind){try{long now=System.currentTimeMillis();Uri uri;String filename;String mime;
            if(kind.equals("edging")){long s=TimeUtil.edgingSheetStart(now);filename="edging_8-week_"+TimeUtil.date(s).replace('/','-')+".pdf";mime="application/pdf";uri=createExportUri(filename,mime);if(uri!=null)Export.edging(this,db,s,TimeUtil.addDays(s,56),uri);}
            else {long s,e;if(kind.equals("xlsx")){s=TimeUtil.weekStart(now);e=TimeUtil.addDays(s,7);filename="timesheet_week_"+TimeUtil.date(s).replace('/','-')+".xlsx";}else if(kind.equals("xlsxMonth")){s=TimeUtil.monthStart(now);e=TimeUtil.addMonths(s,1);filename="timesheet_month_"+TimeUtil.date(s).substring(3).replace('/','-')+".xlsx";}else if(kind.equals("xlsxYear")){s=TimeUtil.yearStart(now);e=TimeUtil.addYears(s,1);filename="timesheet_year_"+TimeUtil.date(s).substring(6)+".xlsx";}else{s=Long.MIN_VALUE;e=Long.MAX_VALUE;filename="timesheet_all_history.xlsx";}mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";uri=createExportUri(filename,mime);if(uri!=null)Export.xlsx(this,db,s,e,uri);}
            new AlertDialog.Builder(this).setTitle("EXPORT SAVED").setMessage("Saved to your Garden Work Tracker export folder.\n\n"+filename).setPositiveButton("OK",null).show();
        }catch(Exception ex){new AlertDialog.Builder(this).setTitle("Export failed").setMessage("The export folder could not be used. Please choose it again.\n\n"+ex.getClass().getSimpleName()).setPositiveButton("CHOOSE FOLDER",(d,w)->chooseExportFolder()).setNegativeButton("CANCEL",null).show();}}

    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(c!=RESULT_OK||d==null)return;try{if(r==PICK_EXPORT_FOLDER){Uri u=d.getData();final int flags=d.getFlags()&(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);getContentResolver().takePersistableUriPermission(u,flags);getSharedPreferences("settings",MODE_PRIVATE).edit().putString("export_tree_uri",u.toString()).apply();if(pendingExportKind!=null){String k=pendingExportKind;pendingExportKind=null;performExport(k);}else{new AlertDialog.Builder(this).setTitle("EXPORT FOLDER SAVED").setMessage("All future timesheets and edging sheets will be saved here automatically.").setPositiveButton("OK",null).show();}}}catch(Exception ex){new AlertDialog.Builder(this).setTitle("Folder not saved").setMessage("Please choose a writable folder again.").setPositiveButton("OK",null).show();}}

    void backup(){try{File dir=new File(getFilesDir(),"job_backups");dir.mkdirs();File out=new File(dir,"backup_"+System.currentTimeMillis()+".db");java.io.FileInputStream in=new java.io.FileInputStream(getDatabasePath(Database.DB));java.io.FileOutputStream o=new java.io.FileOutputStream(out);byte[]b=new byte[8192];int n;while((n=in.read(b))>0)o.write(b,0,n);in.close();o.close();}catch(Exception ignored){}}
    @Override protected void onDestroy(){clock.removeCallbacksAndMessages(null);try{unregisterReceiver(receiver);}catch(Exception ignored){}super.onDestroy();}
}
