package com.gardenworktracker;

import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import java.util.*;

public class Database extends SQLiteOpenHelper {
    public static final String DB="garden_work_tracker.db";
    public Database(Context c){super(c,DB,null,1);}
    @Override public void onCreate(SQLiteDatabase d){
        d.execSQL("CREATE TABLE customers(id TEXT PRIMARY KEY,name TEXT NOT NULL,aliases TEXT NOT NULL DEFAULT '',active INTEGER NOT NULL DEFAULT 1,created_at INTEGER NOT NULL,updated_at INTEGER NOT NULL)");
        d.execSQL("CREATE TABLE locations(id TEXT PRIMARY KEY,customer_id TEXT NOT NULL,lat REAL NOT NULL,lon REAL NOT NULL,accuracy REAL NOT NULL,confidence REAL NOT NULL,created_at INTEGER NOT NULL,last_confirmed INTEGER NOT NULL,active INTEGER NOT NULL DEFAULT 1)");
        d.execSQL("CREATE TABLE visits(id TEXT PRIMARY KEY,customer_id TEXT NOT NULL,start_ts INTEGER NOT NULL,end_ts INTEGER,workers INTEGER NOT NULL,status TEXT NOT NULL,creation_method TEXT NOT NULL,created_at INTEGER NOT NULL,updated_at INTEGER NOT NULL)");
        d.execSQL("CREATE TABLE breaks(id TEXT PRIMARY KEY,visit_id TEXT NOT NULL,start_ts INTEGER NOT NULL,end_ts INTEGER)");
        d.execSQL("CREATE TABLE versions(id TEXT PRIMARY KEY,visit_id TEXT NOT NULL,version_no INTEGER NOT NULL,changed_at INTEGER NOT NULL,source TEXT NOT NULL,before_data TEXT,new_data TEXT)");
        d.execSQL("CREATE INDEX idx_visits_start ON visits(start_ts)");
        d.execSQL("CREATE INDEX idx_locations_customer ON locations(customer_id)");
    }
    @Override public void onUpgrade(SQLiteDatabase d,int oldV,int newV){}
    public static String id(String p){return p+"-"+UUID.randomUUID().toString().replace("-","").substring(0,12);}
    public synchronized ArrayList<HashMap<String,Object>> customers(){
        ArrayList<HashMap<String,Object>> a=new ArrayList<>(); Cursor c=getReadableDatabase().rawQuery("SELECT * FROM customers ORDER BY name COLLATE NOCASE",null);
        while(c.moveToNext()){HashMap<String,Object> m=new HashMap<>();m.put("id",c.getString(c.getColumnIndexOrThrow("id")));m.put("name",c.getString(c.getColumnIndexOrThrow("name")));m.put("aliases",c.getString(c.getColumnIndexOrThrow("aliases")));m.put("active",c.getInt(c.getColumnIndexOrThrow("active"))==1);a.add(m);}c.close();return a;
    }
    public synchronized HashMap<String,Object> customer(String id){
        Cursor c=getReadableDatabase().rawQuery("SELECT * FROM customers WHERE id=?",new String[]{id});if(!c.moveToFirst()){c.close();return null;}
        HashMap<String,Object> m=new HashMap<>();m.put("id",id);m.put("name",c.getString(c.getColumnIndexOrThrow("name")));m.put("aliases",c.getString(c.getColumnIndexOrThrow("aliases")));m.put("active",c.getInt(c.getColumnIndexOrThrow("active"))==1);c.close();return m;
    }
    public synchronized void addCustomer(String name,String aliases){
        long n=System.currentTimeMillis();getWritableDatabase().execSQL("INSERT INTO customers(id,name,aliases,active,created_at,updated_at) VALUES(?,?,?,?,?,?)",new Object[]{id("CUSTOMER"),name,aliases==null?"":aliases,1,n,n});
    }
    public synchronized void updateCustomer(String id,String name,String aliases,boolean active){
        getWritableDatabase().execSQL("UPDATE customers SET name=?,aliases=?,active=?,updated_at=? WHERE id=?",new Object[]{name,aliases,active?1:0,System.currentTimeMillis(),id});
    }
    public synchronized void addLocation(String customerId,double lat,double lon,float accuracy){
        long n=System.currentTimeMillis();getWritableDatabase().execSQL("UPDATE locations SET active=0 WHERE customer_id=?",new Object[]{customerId});
        getWritableDatabase().execSQL("INSERT INTO locations(id,customer_id,lat,lon,accuracy,confidence,created_at,last_confirmed,active) VALUES(?,?,?,?,?,?,?,?,1)",
                new Object[]{id("LOC"),customerId,lat,lon,accuracy,Math.max(0.1,Math.min(1.0,1.0-(accuracy/150.0))),n,n});
    }
    public synchronized ArrayList<HashMap<String,Object>> locations(){
        ArrayList<HashMap<String,Object>> a=new ArrayList<>();Cursor c=getReadableDatabase().rawQuery("SELECT l.*,c.name FROM locations l JOIN customers c ON c.id=l.customer_id WHERE l.active=1",null);
        while(c.moveToNext()){HashMap<String,Object> m=new HashMap<>();m.put("id",c.getString(c.getColumnIndexOrThrow("id")));m.put("customerId",c.getString(c.getColumnIndexOrThrow("customer_id")));m.put("name",c.getString(c.getColumnIndexOrThrow("name")));m.put("lat",c.getDouble(c.getColumnIndexOrThrow("lat")));m.put("lon",c.getDouble(c.getColumnIndexOrThrow("lon")));m.put("accuracy",c.getFloat(c.getColumnIndexOrThrow("accuracy")));m.put("confidence",c.getDouble(c.getColumnIndexOrThrow("confidence")));a.add(m);}c.close();return a;
    }
    public synchronized HashMap<String,Object> activeVisit(){
        Cursor c=getReadableDatabase().rawQuery("SELECT * FROM visits WHERE status IN('WORKING','ON_BREAK','POSSIBLE_DEPARTURE') LIMIT 1",null);if(!c.moveToFirst()){c.close();return null;}
        HashMap<String,Object> m=visitFrom(c);c.close();return m;
    }
    private HashMap<String,Object> visitFrom(Cursor c){
        HashMap<String,Object> m=new HashMap<>();String[] cols={"id","customer_id","start_ts","end_ts","workers","status","creation_method","created_at","updated_at"};
        for(String x:cols){int i=c.getColumnIndexOrThrow(x);m.put(x,c.isNull(i)?null:c.getString(i));}
        return m;
    }
    public synchronized void insertVisit(String customerId,long start,int workers,String method){
        long n=System.currentTimeMillis();getWritableDatabase().execSQL("INSERT INTO visits(id,customer_id,start_ts,end_ts,workers,status,creation_method,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?)",
                new Object[]{id("VISIT"),customerId,start,null,workers,"WORKING",method,n,n});
    }
    public synchronized void updateVisit(String id,String customerId,long start,Long end,int workers,String status,String method){
        long n=System.currentTimeMillis();getWritableDatabase().execSQL("UPDATE visits SET customer_id=?,start_ts=?,end_ts=?,workers=?,status=?,creation_method=?,updated_at=? WHERE id=?",
                new Object[]{customerId,start,end,workers,status,method,n,id});
    }
    public synchronized void addBreak(String visitId,long start){
        getWritableDatabase().execSQL("INSERT INTO breaks(id,visit_id,start_ts,end_ts) VALUES(?,?,?,NULL)",new Object[]{id("BREAK"),visitId,start});
    }
    public synchronized HashMap<String,Object> openBreak(String visitId){
        Cursor c=getReadableDatabase().rawQuery("SELECT * FROM breaks WHERE visit_id=? AND end_ts IS NULL ORDER BY start_ts DESC LIMIT 1",new String[]{visitId});if(!c.moveToFirst()){c.close();return null;}
        HashMap<String,Object> m=new HashMap<>();m.put("id",c.getString(c.getColumnIndexOrThrow("id")));m.put("start",c.getLong(c.getColumnIndexOrThrow("start_ts")));c.close();return m;
    }
    public synchronized void closeBreak(String id,long end){getWritableDatabase().execSQL("UPDATE breaks SET end_ts=? WHERE id=?",new Object[]{end,id});}
    public synchronized ArrayList<HashMap<String,Object>> visits(long from,long to){
        ArrayList<HashMap<String,Object>> a=new ArrayList<>();Cursor c=getReadableDatabase().rawQuery("SELECT v.*,c.name FROM visits v LEFT JOIN customers c ON c.id=v.customer_id WHERE v.start_ts>=? AND v.start_ts<? ORDER BY v.start_ts DESC",new String[]{String.valueOf(from),String.valueOf(to)});
        while(c.moveToNext()){HashMap<String,Object> m=visitFrom(c);m.put("name",c.getString(c.getColumnIndexOrThrow("name")));a.add(m);}c.close();return a;
    }
    public synchronized ArrayList<HashMap<String,Object>> allVisits(){return visits(Long.MIN_VALUE,Long.MAX_VALUE);}
    public synchronized long breakMinutes(String visitId){
        long total=0;Cursor c=getReadableDatabase().rawQuery("SELECT start_ts,end_ts FROM breaks WHERE visit_id=?",new String[]{visitId});
        while(c.moveToNext()&&!c.isNull(1)) total+=(c.getLong(1)-c.getLong(0))/60000; c.close();return total;
    }
    public synchronized void version(String visitId,int n,String before,String after,String source){
        getWritableDatabase().execSQL("INSERT INTO versions(id,visit_id,version_no,changed_at,source,before_data,new_data) VALUES(?,?,?,?,?,?,?)",
                new Object[]{id("VERSION"),visitId,n,System.currentTimeMillis(),source,before,after});
    }
    public synchronized int versionCount(String visitId){Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM versions WHERE visit_id=?",new String[]{visitId});c.moveToFirst();int n=c.getInt(0);c.close();return n;}
    public synchronized void deleteVisit(String visitId, String beforeData){
        SQLiteDatabase d=getWritableDatabase();
        d.beginTransaction();
        try {
            Cursor c=d.rawQuery("SELECT * FROM visits WHERE id=?",new String[]{visitId});
            if(c.moveToFirst()){
                int n=0; Cursor vc=d.rawQuery("SELECT COUNT(*) FROM versions WHERE visit_id=?",new String[]{visitId});
                if(vc.moveToFirst()) n=vc.getInt(0); vc.close();
                d.delete("breaks","visit_id=?",new String[]{visitId});
                d.delete("visits","id=?",new String[]{visitId});
                d.execSQL("INSERT INTO versions(id,visit_id,version_no,changed_at,source,before_data,new_data) VALUES(?,?,?,?,?,?,?)",
                        new Object[]{id("VERSION"),visitId,n+1,System.currentTimeMillis(),"DELETE",beforeData,"DELETED"});
            }
            c.close();
            d.setTransactionSuccessful();
        } finally { d.endTransaction(); }
    }
}