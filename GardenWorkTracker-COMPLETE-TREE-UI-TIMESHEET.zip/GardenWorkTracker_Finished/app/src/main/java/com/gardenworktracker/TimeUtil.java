package com.gardenworktracker;
import java.text.*;import java.util.*;
public final class TimeUtil{
 public static final TimeZone UK=TimeZone.getTimeZone("Europe/London");
 public static String time(long x){SimpleDateFormat f=new SimpleDateFormat("HH:mm",Locale.UK);f.setTimeZone(UK);return f.format(new Date(x));}
 public static String date(long x){SimpleDateFormat f=new SimpleDateFormat("dd/MM/yyyy",Locale.UK);f.setTimeZone(UK);return f.format(new Date(x));}
 public static String shortDate(long x){SimpleDateFormat f=new SimpleDateFormat("dd MMM",Locale.UK);f.setTimeZone(UK);return f.format(new Date(x));}
 public static Calendar cal(long x){Calendar c=Calendar.getInstance(UK,Locale.UK);c.setTimeInMillis(x);return c;}
 public static long dayStart(long x){Calendar c=cal(x);c.set(Calendar.HOUR_OF_DAY,0);c.set(Calendar.MINUTE,0);c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);return c.getTimeInMillis();}
 public static long weekStart(long x){Calendar c=cal(x);c.setFirstDayOfWeek(Calendar.MONDAY);c.set(Calendar.DAY_OF_WEEK,Calendar.MONDAY);return dayStart(c.getTimeInMillis());}
 public static long monthStart(long x){Calendar c=cal(x);c.set(Calendar.DAY_OF_MONTH,1);return dayStart(c.getTimeInMillis());}
 public static long yearStart(long x){Calendar c=cal(x);c.set(Calendar.DAY_OF_YEAR,1);return dayStart(c.getTimeInMillis());}
 public static long addDays(long x,int n){Calendar c=cal(x);c.add(Calendar.DAY_OF_MONTH,n);return c.getTimeInMillis();}
 public static long addMonths(long x,int n){Calendar c=cal(x);c.add(Calendar.MONTH,n);return c.getTimeInMillis();}
 public static long addYears(long x,int n){Calendar c=cal(x);c.add(Calendar.YEAR,n);return c.getTimeInMillis();}
 /** Eight-week edging sheets. Each sheet is a stable block of eight Monday-Sunday weeks. */
 public static long edgingSheetStart(long x){
  long w=weekStart(x);
  Calendar a=Calendar.getInstance(UK,Locale.UK);a.clear();a.set(2026,Calendar.JANUARY,5,0,0,0);
  long anchor=a.getTimeInMillis();
  long weeks=Math.floorDiv(w-anchor,7L*24L*60L*60L*1000L);
  long block=Math.floorDiv(weeks,8);
  return addDays(anchor,(int)(block*56));
 }
}
