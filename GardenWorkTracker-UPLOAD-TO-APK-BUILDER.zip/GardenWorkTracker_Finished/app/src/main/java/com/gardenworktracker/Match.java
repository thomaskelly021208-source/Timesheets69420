package com.gardenworktracker;
public final class Match{
 public static String norm(String s){return s.toLowerCase().replaceAll("[^a-z0-9]","");}
 public static int dist(String a,String b){a=norm(a);b=norm(b);int[][]d=new int[a.length()+1][b.length()+1];for(int i=0;i<=a.length();i++)d[i][0]=i;for(int j=0;j<=b.length();j++)d[0][j]=j;for(int i=1;i<=a.length();i++)for(int j=1;j<=b.length();j++)d[i][j]=Math.min(Math.min(d[i-1][j]+1,d[i][j-1]+1),d[i-1][j-1]+(a.charAt(i-1)==b.charAt(j-1)?0:1));return d[a.length()][b.length()];}
 public static int score(String q,String name,String aliases){int s=dist(q,name);if(aliases!=null)for(String a:aliases.split("\\|"))if(!a.trim().isEmpty())s=Math.min(s,dist(q,a));return s;}
}