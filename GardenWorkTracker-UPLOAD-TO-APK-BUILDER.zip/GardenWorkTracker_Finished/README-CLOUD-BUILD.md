# Garden Work Tracker — cloud APK build

This is a native Android Gradle project prepared for a cloud source builder.

Build command:
`./gradlew assembleRelease`

Expected APK:
`app/build/outputs/apk/release/app-release.apk`

The project contains a self-bootstrapping `gradlew` script which downloads Gradle 8.9 on the build machine if needed. Do not include `.gradle-dist` in uploads; it is generated during the build.
