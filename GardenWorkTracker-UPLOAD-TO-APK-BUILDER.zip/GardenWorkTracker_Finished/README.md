# Garden Work Tracker — Finished offline-first build

This build is deliberately dependency-light: native Android Activity/UI, SQLiteOpenHelper, Android GNSS LocationManager, native PdfDocument, and a small XLSX writer. It does not need internet, a SIM, Wi-Fi, Room, Compose, or a cloud service for normal job recording.

## What is included
- Persistent SQLite database.
- Exact phone-clock timestamps in Europe/London.
- Customer IDs, aliases, deactivation.
- Customer location storage.
- Fuzzy customer matching.
- GPS candidate arrival prompts.
- Conservative departure prompts.
- Manual start/finish fallback.
- Breaks.
- Worker count.
- Active-job recovery after process/app restart.
- Historical timesheet browsing.
- Week/month/year XLSX export.
- A4 landscape edging-sheet PDF export.
- Manual timesheet correction with version records.
- Automatic local post-job database backup copies.
- Android Auto Backup configuration for the database/backup directory.

## Install
1. Install the current Android Studio on a computer.
2. Open this folder as an existing project.
3. Let Gradle sync.
4. Connect the Android phone with USB debugging enabled.
5. Press Run.
6. Allow location permissions.
7. For reliable background GPS, Android Settings > Apps > Garden Work Tracker > Permissions > Location > Allow all the time (where the phone offers it).
8. Keep battery optimisation disabled for the app if the phone manufacturer is aggressive about background apps.

## Important
The app is offline-first. Internet is not required for recording work. GPS itself can operate without mobile data.

The app deliberately never silently finishes a job from one GPS point. GPS only produces a suggestion; the worker confirms it.

For a production deployment, test GPS behaviour on the exact phone/vehicle and Android version used in the van, especially background-location and battery-management behaviour.
