@echo off
setlocal
set BASE_DIR=%~dp0
set GRADLE_VERSION=8.9
set DIST=%BASE_DIR%.gradle-dist\gradle-%GRADLE_VERSION%
if not exist "%DIST%\bin\gradle.bat" (
  if not exist "%BASE_DIR%.gradle-dist" mkdir "%BASE_DIR%.gradle-dist"
  set ZIP=%BASE_DIR%.gradle-dist\gradle-%GRADLE_VERSION%-bin.zip
  if not exist "%ZIP%" powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip -OutFile '%ZIP%'"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Force '%ZIP%' '%BASE_DIR%.gradle-dist'"
)
call "%DIST%\bin\gradle.bat" %*
endlocal
