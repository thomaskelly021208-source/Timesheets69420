package com.gardenworktracker;

import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import java.util.*;

public class Database extends SQLiteOpenHelper {
    public static final String DB="garden_work_tracker.db";
    public Database(Context c){super(c,DB,null,2);}
    @Override public void onCreate(SQLiteDatabase d){
        d.execSQL("CREATE TABLE customers(id TEXT PRIMARY KEY,name TEXT NOT NULL,aliases TEXT NOT NULL DEFAULT '',active INTEGER NOT NULL DEFAULT 1,created_at INTEGER NOT NULL,updated_at INTEGER NOT NULL)");
        d.execSQL("CREATE TABLE locations(id TEXT PRIMARY KEY,customer_id TEXT NOT NULL,lat REAL NOT NULL,lon REAL NOT NULL,accuracy REAL NOT NULL,confidence REAL NOT NULL,created_at INTEGER NOT NULL,last_confirmed INTEGER NOT NULL,active INTEGER NOT NULL DEFAULT 1)");
        d.execSQL("CREATE TABLE visits(id TEXT PRIMARY KEY,customer_id TEXT NOT NULL,start_ts INTEGER NOT NULL,end_ts INTEGER,workers INTEGER NOT NULL,status TEXT NOT NULL,creation_method TEXT NOT NULL,created_at INTEGER NOT NULL,updated_at INTEGER NOT NULL)");
        d.execSQL("CREATE TABLE breaks(id TEXT PRIMARY KEY,visit_id TEXT NOT NULL,start_ts INTEGER NOT NULL,end_ts INTEGER)");
        d.execSQL("CREATE TABLE visit_workers(id TEXT PRIMARY KEY,visit_id TEXT NOT NULL,worker_order INTEGER NOT NULL,name TEXT NOT NULL)");
        d.execSQL("CREATE TABLE worker_breaks(id TEXT PRIMARY KEY,visit_id TEXT NOT NULL,worker_id TEXT NOT NULL,start_ts INTEGER NOT NULL,end_ts INTEGER)");
        d.execSQL("CREATE TABLE versions(id TEXT PRIMARY KEY,visit_id TEXT NOT NULL,version_no INTEGER NOT NULL,changed_at INTEGER NOT NULL,source TEXT NOT NULL,before_data TEXT,new_data TEXT)");
        d.execSQL("CREATE INDEX idx_visits_start ON visits(start_ts)");
        d.execSQL("CREATE INDEX idx_locations_customer ON locations(customer_id)");
        d.execSQL("CREATE INDEX idx_visit_workers_visit ON visit_workers(visit_id,worker_order)");
        d.execSQL("CREATE INDEX idx_worker_breaks_visit ON worker_breaks(visit_id,start_ts)");
    }
    @Override public void onUpgrade(SQLiteDatabase d,int oldV,int newV){
        if(oldV<2){
            d.execSQL("CREATE TABLE IF NOT EXISTS visit_workers(id TEXT PRIMARY KEY,visit_id TEXT NOT NULL,worker_order INTEGER NOT NULL,name TEXT NOT NULL)");
            d.execSQL("CREATE TABLE IF NOT EXISTS worker_breaks(id TEXT PRIMARY KEY,visit_id TEXT NOT NULL,worker_id TEXT NOT NULL,start_ts INTEGER NOT NULL,end_ts INTEGER)");
            d.execSQL("CREATE INDEX IF NOT EXISTS idx_visit_workers_visit ON visit_workers(visit_id,worker_order)");
            d.execSQL("CREATE INDEX IF NOT EXISTS idx_worker_breaks_visit ON worker_breaks(visit_id,start_ts)");
            Cursor c=d.rawQuery("SELECT id,workers FROM visits WHERE id NOT IN (SELECT DISTINCT visit_id FROM visit_workers)",null);
            ArrayList<String[]> pending=new ArrayList<>();
            while(c.moveToNext()){String vid=c.getString(0);int n=Math.max(1,c.getInt(1));pending.add(new String[]{vid,String.valueOf(n)});}c.close();
            for(String[] row:pending){String vid=row[0];int n=Integer.parseInt(row[1]);for(int i=1;i<=n;i++)d.execSQL("INSERT INTO visit_workers(id,visit_id,worker_order,name) VALUES(?,?,?,?)",new Object[]{id("WORKER"),vid,i,"Worker "+i});}
        }
    }
    public static String id(String p){return p+"-"+UUID.randomUUID().toString().replace("-","").substring(0,12);}
    public synchronized ArrayList<HashMap<String,Object>> customers(){
        ArrayList<HashMap<String,Object>> a=new ArrayList<>(); Cursor c=getReadableDatabase().rawQuery("SELECT * FROM customers ORDER BY name COLLATE NOCASE",null);
        while(c.moveToNext()){HashMap<String,Object> m=new HashMap<>();m.put("id",c.getString(c.getColumnIndexOrThrow("id")));m.put("name",c.getString(c.getColumnIndexOrThrow("name")));m.put("aliases",c.getString(c.getColumnIndexOrThrow("aliases")));m.put("active",c.getInt(c.getColumnIndexOrThrow("active"))==1);a.add(m);}c.close();return a;
    }
    public synchronized HashMap<String,Object> customer(String id){
        Cursor c=getReadableDatabase().rawQuery("SELECT * FROM customers WHERE id=?",new String[]{id});if(!c.moveToFirst()){c.close();return null;}
        HashMap<String,Object> m=new HashMap<>();m.put("id",id);m.put("name",c.getString(c.getColumnIndexOrThrow("name")));m.put("aliases",c.getString(c.getColumnIndexOrThrow("aliases")));m.put("active",c.getInt(c.getColumnIndexOrThrow("active"))==1);c.close();return m;
    }
    public synchronized void addCustomer(String name,String aliases){
        long n=System.currentTimeMillis();getWritableDatabase().execSQL("INSERT INTO customers(id,name,aliases,active,created_at,updated_at) VALUES(?,?,?,?,?,?)",new Object[]{id("CUSTOMER"),name,aliases==null?"":aliases,1,n,n});
    }
    public synchronized void updateCustomer(String id,String name,String aliases,boolean active){
        getWritableDatabase().execSQL("UPDATE customers SET name=?,aliases=?,active=?,updated_at=? WHERE id=?",new Object[]{name,aliases,active?1:0,System.currentTimeMillis(),id});
    }
    public synchronized void addLocation(String customerId,double lat,double lon,float accuracy){
        long n=System.currentTimeMillis();getWritableDatabase().execSQL("UPDATE locations SET active=0 WHERE customer_id=?",new Object[]{customerId});
        getWritableDatabase().execSQL("INSERT INTO locations(id,customer_id,lat,lon,accuracy,confidence,created_at,last_confirmed,active) VALUES(?,?,?,?,?,?,?,?,1)",new Object[]{id("LOC"),customerId,lat,lon,accuracy,Math.max(0.1,Math.min(1.0,1.0-(accuracy/150.0))),n,n});
    }
    public synchronized ArrayList<HashMap<String,Object>> locations(){
        ArrayList<HashMap<String,Object>> a=new ArrayList<>();Cursor c=getReadableDatabase().rawQuery("SELECT l.*,c.name FROM locations l JOIN customers c ON c.id=l.customer_id WHERE l.active=1",null);
        while(c.moveToNext()){HashMap<String,Object> m=new HashMap<>();m.put("id",c.getString(c.getColumnIndexOrThrow("id")));m.put("customerId",c.getString(c.getColumnIndexOrThrow("customer_id")));m.put("name",c.getString(c.getColumnIndexOrThrow("name")));m.put("lat",c.getDouble(c.getColumnIndexOrThrow("lat")));m.put("lon",c.getDouble(c.getColumnIndexOrThrow("lon")));m.put("accuracy",c.getFloat(c.getColumnIndexOrThrow("accuracy")));m.put("confidence",c.getDouble(c.getColumnIndexOrThrow("confidence")));a.add(m);}c.close();return a;
    }
    public synchronized HashMap<String,Object> activeVisit(){
        Cursor c=getReadableDatabase().rawQuery("SELECT * FROM visits WHERE status IN('WORKING','ON_BREAK','POSSIBLE_DEPARTURE') LIMIT 1",null);if(!c.moveToFirst()){c.close();return null;}
        HashMap<String,Object> m=visitFrom(c);c.close();return m;
    }
    private HashMap<String,Object> visitFrom(Cursor c){
        HashMap<String,Object> m=new HashMap<>();String[] cols={"id","customer_id","start_ts","end_ts","workers","status","creation_method","created_at","updated_at"};
        for(String x:cols){int i=c.getColumnIndexOrThrow(x);m.put(x,c.isNull(i)?null:c.getString(i));}
        return m;
    }
    public synchronized void insertVisit(String customerId,long start,int workers,String method){
        ArrayList<String> names=new ArrayList<>();for(int i=1;i<=Math.max(1,workers);i++)names.add("Worker "+i);insertVisit(customerId,start,names,method);
    }
    public synchronized void insertVisit(String customerId,long start,List<String> names,String method){
        SQLiteDatabase d=getWritableDatabase();d.beginTransaction();
        try{
            int count=Math.max(1,names.size());long n=System.currentTimeMillis();String vid=id("VISIT");
            d.execSQL("INSERT INTO visits(id,customer_id,start_ts,end_ts,workers,status,creation_method,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?)",new Object[]{vid,customerId,start,null,count,"WORKING",method,n,n});
            int order=1;for(String raw:names){String name=raw==null?"":raw.trim();if(name.isEmpty())name="Worker "+order;d.execSQL("INSERT INTO visit_workers(id,visit_id,worker_order,name) VALUES(?,?,?,?)",new Object[]{id("WORKER"),vid,order++,name});}
            d.setTransactionSuccessful();
        }finally{d.endTransaction();}
    }
    public synchronized void updateVisit(String id,String customerId,long start,Long end,int workers,String status,String method){
        long n=System.currentTimeMillis();getWritableDatabase().execSQL("UPDATE visits SET customer_id=?,start_ts=?,end_ts=?,workers=?,status=?,creation_method=?,updated_at=? WHERE id=?",new Object[]{customerId,start,end,workers,status,method,n,id});
    }
    public synchronized ArrayList<HashMap<String,Object>> workers(String visitId){
        ArrayList<HashMap<String,Object>> a=new ArrayList<>();Cursor c=getReadableDatabase().rawQuery("SELECT * FROM visit_workers WHERE visit_id=? ORDER BY worker_order",new String[]{visitId});
        while(c.moveToNext()){HashMap<String,Object> m=new HashMap<>();m.put("id",c.getString(c.getColumnIndexOrThrow("id")));m.put("visit_id",visitId);m.put("worker_order",c.getInt(c.getColumnIndexOrThrow("worker_order")));m.put("name",c.getString(c.getColumnIndexOrThrow("name")));a.add(m);}c.close();return a;
    }
    public synchronized void resizeWorkers(String visitId,List<String> names){
        SQLiteDatabase d=getWritableDatabase();d.beginTransaction();try{
            ArrayList<HashMap<String,Object>> old=workers(visitId);int target=Math.max(1,names.size());
            if(target<old.size()){
                for(int i=target;i<old.size();i++){
                    String wid=String.valueOf(old.get(i).get("id"));Cursor c=d.rawQuery("SELECT 1 FROM worker_breaks WHERE worker_id=? LIMIT 1",new String[]{wid});boolean has=c.moveToFirst();c.close();if(has)throw new IllegalArgumentException("Cannot remove a worker who has break records");
                }
                for(int i=old.size()-1;i>=target;i--)d.delete("visit_workers","id=?",new String[]{String.valueOf(old.get(i).get("id"))});
            }
            old=workers(visitId);
            for(int i=0;i<target;i++){
                String name=names.get(i)==null?"":names.get(i).trim();if(name.isEmpty())name="Worker "+(i+1);
                if(i<old.size()) d.execSQL("UPDATE visit_workers SET worker_order=?,name=? WHERE id=?",new Object[]{i+1,name,String.valueOf(old.get(i).get("id"))});
                else d.execSQL("INSERT INTO visit_workers(id,visit_id,worker_order,name) VALUES(?,?,?,?)",new Object[]{id("WORKER"),visitId,i+1,name});
            }
            d.execSQL("UPDATE visits SET workers=?,updated_at=? WHERE id=?",new Object[]{target,System.currentTimeMillis(),visitId});d.setTransactionSuccessful();
        }finally{d.endTransaction();}
    }
    public synchronized void updateWorkerBreak(String id,long start,Long end){getWritableDatabase().execSQL("UPDATE worker_breaks SET start_ts=?,end_ts=? WHERE id=?",new Object[]{start,end,id});}

    public synchronized boolean hasWorkerBreaks(String visitId){
        Cursor c=getReadableDatabase().rawQuery("SELECT 1 FROM worker_breaks WHERE visit_id=? LIMIT 1",new String[]{visitId});
        boolean yes=c.moveToFirst();c.close();return yes;
    }
    public synchronized HashMap<String,Object> openWorkerBreak(String visitId,String workerId){
        Cursor c=getReadableDatabase().rawQuery("SELECT * FROM worker_breaks WHERE visit_id=? AND worker_id=? AND end_ts IS NULL ORDER BY start_ts DESC LIMIT 1",new String[]{visitId,workerId});
        if(!c.moveToFirst()){c.close();return null;}
        HashMap<String,Object> m=new HashMap<>();m.put("id",c.getString(c.getColumnIndexOrThrow("id")));m.put("start_ts",c.getLong(c.getColumnIndexOrThrow("start_ts")));c.close();return m;
    }
    public synchronized void startWorkerBreak(String visitId,String workerId,long start){
        getWritableDatabase().execSQL("INSERT INTO worker_breaks(id,visit_id,worker_id,start_ts,end_ts) VALUES(?,?,?,?,NULL)",new Object[]{id("WBREAK"),visitId,workerId,start});
    }
    public synchronized void closeWorkerBreak(String breakId,long end){
        getWritableDatabase().execSQL("UPDATE worker_breaks SET end_ts=? WHERE id=? AND end_ts IS NULL",new Object[]{end,breakId});
    }
    public synchronized ArrayList<HashMap<String,Object>> workerBreaks(String visitId){
        ArrayList<HashMap<String,Object>> a=new ArrayList<>();
        Cursor c=getReadableDatabase().rawQuery("SELECT wb.*,vw.name FROM worker_breaks wb JOIN visit_workers vw ON vw.id=wb.worker_id WHERE wb.visit_id=? ORDER BY wb.start_ts,vw.worker_order",new String[]{visitId});
        while(c.moveToNext()){
            HashMap<String,Object> m=new HashMap<>();
            m.put("id",c.getString(c.getColumnIndexOrThrow("id")));m.put("visit_id",visitId);m.put("worker_id",c.getString(c.getColumnIndexOrThrow("worker_id")));
            m.put("name",c.getString(c.getColumnIndexOrThrow("name")));m.put("start_ts",c.getLong(c.getColumnIndexOrThrow("start_ts")));
            int ei=c.getColumnIndexOrThrow("end_ts");m.put("end_ts",c.isNull(ei)?null:c.getLong(ei));a.add(m);
        }c.close();return a;
    }
    private synchronized double workerBreakMinutes(String visitId,int workers,long asOf){
        int n=Math.max(1,workers);long total=0;
        Cursor c=getReadableDatabase().rawQuery("SELECT start_ts,end_ts FROM worker_breaks WHERE visit_id=?",new String[]{visitId});
        while(c.moveToNext()){long s=c.getLong(0);long e=c.isNull(1)?asOf:c.getLong(1);if(e>s)total+=e-s;}
        c.close();return total/60000.0/n;
    }

    // Legacy global-break API retained so existing historical data remains readable.
    public synchronized void addBreak(String visitId,long start){getWritableDatabase().execSQL("INSERT INTO breaks(id,visit_id,start_ts,end_ts) VALUES(?,?,?,NULL)",new Object[]{id("BREAK"),visitId,start});}
    public synchronized HashMap<String,Object> openBreak(String visitId){Cursor c=getReadableDatabase().rawQuery("SELECT * FROM breaks WHERE visit_id=? AND end_ts IS NULL ORDER BY start_ts DESC LIMIT 1",new String[]{visitId});if(!c.moveToFirst()){c.close();return null;}HashMap<String,Object> m=new HashMap<>();m.put("id",c.getString(c.getColumnIndexOrThrow("id")));m.put("start",c.getLong(c.getColumnIndexOrThrow("start_ts")));c.close();return m;}
    public synchronized void closeBreak(String id,long end){getWritableDatabase().execSQL("UPDATE breaks SET end_ts=? WHERE id=?",new Object[]{end,id});}
    public synchronized void closeOpenLegacyBreaks(String visitId,long end){getWritableDatabase().execSQL("UPDATE breaks SET end_ts=? WHERE visit_id=? AND end_ts IS NULL",new Object[]{end,visitId});}
    public synchronized double breakMinutes(String visitId){
        Cursor wc=getReadableDatabase().rawQuery("SELECT workers FROM visits WHERE id=?",new String[]{visitId});int workers=1;if(wc.moveToFirst())workers=Math.max(1,wc.getInt(0));wc.close();
        if(hasWorkerBreaks(visitId))return workerBreakMinutes(visitId,workers,System.currentTimeMillis());
        long total=0;Cursor c=getReadableDatabase().rawQuery("SELECT start_ts,end_ts FROM breaks WHERE visit_id=?",new String[]{visitId});while(c.moveToNext()&&!c.isNull(1))total+=c.getLong(1)-c.getLong(0);c.close();return total/60000.0;
    }
    public synchronized double breakMinutesAt(String visitId,int workers,long asOf){
        if(hasWorkerBreaks(visitId))return workerBreakMinutes(visitId,workers,asOf);
        long total=0;Cursor c=getReadableDatabase().rawQuery("SELECT start_ts,end_ts FROM breaks WHERE visit_id=?",new String[]{visitId});while(c.moveToNext()){long e=c.isNull(1)?asOf:c.getLong(1);if(e>c.getLong(0))total+=e-c.getLong(0);}c.close();return total/60000.0;
    }
    public synchronized void finishVisit(String visitId,String customerId,long start,long end,int workers,String method){
        SQLiteDatabase d=getWritableDatabase();d.beginTransaction();try{
            d.execSQL("UPDATE worker_breaks SET end_ts=? WHERE visit_id=? AND end_ts IS NULL",new Object[]{end,visitId});
            d.execSQL("UPDATE breaks SET end_ts=? WHERE visit_id=? AND end_ts IS NULL",new Object[]{end,visitId});
            d.execSQL("UPDATE visits SET customer_id=?,start_ts=?,end_ts=?,workers=?,status='COMPLETED',creation_method=?,updated_at=? WHERE id=?",new Object[]{customerId,start,end,workers,method,System.currentTimeMillis(),visitId});
            d.setTransactionSuccessful();
        }finally{d.endTransaction();}
    }
    public synchronized ArrayList<HashMap<String,Object>> visits(long from,long to){
        ArrayList<HashMap<String,Object>> a=new ArrayList<>();Cursor c=getReadableDatabase().rawQuery("SELECT v.*,c.name FROM visits v LEFT JOIN customers c ON c.id=v.customer_id WHERE v.start_ts>=? AND v.start_ts<? ORDER BY v.start_ts DESC",new String[]{String.valueOf(from),String.valueOf(to)});
        while(c.moveToNext()){HashMap<String,Object> m=visitFrom(c);m.put("name",c.getString(c.getColumnIndexOrThrow("name")));a.add(m);}c.close();return a;
    }
    public synchronized ArrayList<HashMap<String,Object>> allVisits(){return visits(Long.MIN_VALUE,Long.MAX_VALUE);}
    public synchronized void version(String visitId,int n,String before,String after,String source){getWritableDatabase().execSQL("INSERT INTO versions(id,visit_id,version_no,changed_at,source,before_data,new_data) VALUES(?,?,?,?,?,?,?)",new Object[]{id("VERSION"),visitId,n,System.currentTimeMillis(),source,before,after});}
    public synchronized int versionCount(String visitId){Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM versions WHERE visit_id=?",new String[]{visitId});c.moveToFirst();int n=c.getInt(0);c.close();return n;}
    public synchronized void deleteVisit(String visitId,String beforeData){
        SQLiteDatabase d=getWritableDatabase();d.beginTransaction();try{Cursor c=d.rawQuery("SELECT * FROM visits WHERE id=?",new String[]{visitId});if(c.moveToFirst()){int n=0;Cursor vc=d.rawQuery("SELECT COUNT(*) FROM versions WHERE visit_id=?",new String[]{visitId});if(vc.moveToFirst())n=vc.getInt(0);vc.close();d.delete("worker_breaks","visit_id=?",new String[]{visitId});d.delete("visit_workers","visit_id=?",new String[]{visitId});d.delete("breaks","visit_id=?",new String[]{visitId});d.delete("visits","id=?",new String[]{visitId});d.execSQL("INSERT INTO versions(id,visit_id,version_no,changed_at,source,before_data,new_data) VALUES(?,?,?,?,?,?,?)",new Object[]{id("VERSION"),visitId,n+1,System.currentTimeMillis(),"DELETE",beforeData,"DELETED"});}c.close();d.setTransactionSuccessful();}finally{d.endTransaction();}
    }
}
