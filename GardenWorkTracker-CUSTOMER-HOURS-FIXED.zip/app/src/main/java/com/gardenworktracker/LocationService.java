package com.gardenworktracker;
import android.Manifest;import android.app.*;import android.content.*;import android.content.pm.PackageManager;import android.location.*;import android.os.*;import java.util.*;
public class LocationService extends Service{
 static final String ACTION_CANDIDATE="com.gardenworktracker.CANDIDATE";
 static final String ACTION_DEPART="com.gardenworktracker.DEPART";
 LocationManager lm;Database db;Handler h=new Handler(Looper.getMainLooper());Location last;static volatile Location lastLocation;String candidateId;long candidateSince=0;int movingSamples=0;
 LocationListener listener=new LocationListener(){
  public void onLocationChanged(Location l){if(l==null)return;last=l;lastLocation=l;evaluate(l);}
  public void onProviderEnabled(String p){} public void onProviderDisabled(String p){} public void onStatusChanged(String p,int s,Bundle b){}
 };
 @Override public void onCreate(){super.onCreate();db=new Database(this);createChannel();Notification.Builder nb;
if(Build.VERSION.SDK_INT>=26) nb=new Notification.Builder(this,"tracker"); else nb=new Notification.Builder(this);
nb.setContentTitle("Garden Work Tracker").setContentText("Monitoring location").setSmallIcon(android.R.drawable.ic_menu_mylocation).setOngoing(true);
startForeground(8,nb.build());start();}
 void start(){
  lm=(LocationManager)getSystemService(LOCATION_SERVICE);
  if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED)return;
  try{lm.requestLocationUpdates(LocationManager.GPS_PROVIDER,5000,5,listener,Looper.getMainLooper());}catch(Exception ignored){}
 }
 double dist(double a,double b,double c,double d){double R=6371000;double p=Math.toRadians(c-a),q=Math.toRadians(d-b);double x=Math.sin(p/2)*Math.sin(p/2)+Math.cos(Math.toRadians(a))*Math.cos(Math.toRadians(c))*Math.sin(q/2)*Math.sin(q/2);return 2*R*Math.atan2(Math.sqrt(x),Math.sqrt(1-x));}
 void evaluate(Location l){
  ArrayList<HashMap<String,Object>> locs=db.locations();HashMap<String,Object> active=db.activeVisit();
  if(active==null){
   if(l.hasSpeed()&&l.getSpeed()>4)return;
   HashMap<String,Object> best=null;double bd=Double.MAX_VALUE;
   for(HashMap<String,Object> x:locs){double d=dist(l.getLatitude(),l.getLongitude(),(double)x.get("lat"),(double)x.get("lon"));double radius=Math.max(25,l.getAccuracy()+((double)x.get("accuracy"))+10);if(d<=radius&&d<bd){bd=d;best=x;}}
   if(best!=null){String id=(String)best.get("customerId");if(!id.equals(candidateId)){candidateId=id;candidateSince=System.currentTimeMillis();}else if(System.currentTimeMillis()-candidateSince>12000){Intent i=new Intent(ACTION_CANDIDATE);i.putExtra("customerId",id);i.putExtra("distance",(int)bd);sendBroadcast(i);candidateSince=System.currentTimeMillis()+60000;}}
  }else{
   boolean moving=l.hasSpeed()&&l.getSpeed()>2.0; if(moving)movingSamples++;else movingSamples=0;
   if(movingSamples>=3){String cid=(String)active.get("customer_id");HashMap<String,Object> nearest=null;double bd=Double.MAX_VALUE;for(HashMap<String,Object>x:locs)if(cid.equals(x.get("customerId"))){double d=dist(l.getLatitude(),l.getLongitude(),(double)x.get("lat"),(double)x.get("lon"));if(d<bd){bd=d;nearest=x;}}double radius=nearest==null?60:Math.max(35,l.getAccuracy()+(float)nearest.get("accuracy")+20);if(bd>radius){Intent i=new Intent(ACTION_DEPART);i.putExtra("distance",(int)bd);sendBroadcast(i);movingSamples=0;}}
  }
 }
 void createChannel(){NotificationManager n=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);n.createNotificationChannel(new NotificationChannel("tracker","Work tracking",NotificationManager.IMPORTANCE_LOW));}
 @Override public int onStartCommand(Intent i,int f,int s){return START_STICKY;}
 @Override public void onDestroy(){try{lm.removeUpdates(listener);}catch(Exception ignored){}super.onDestroy();}
 @Override public IBinder onBind(Intent i){return null;}
}